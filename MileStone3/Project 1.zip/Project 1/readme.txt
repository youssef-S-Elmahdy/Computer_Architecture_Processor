Hussein Heggi - 900213220
Youssef Elmahdy - 900212370


Project Status:


The project works for all 40 instructions using a pipelined implementation and a single memory.