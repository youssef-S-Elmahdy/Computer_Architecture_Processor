Student Names:
Youssef Elmahdy - 900212370
Hussein Heggi - 900213220 


Project Status:
32 instructions were implemented and tested in single cycle implementation.
Completed all RISC-V 32I instructions except for (lb, lh, llbu, lhu, sb, sh, ecall, ebreak) which will be implemented in the next milestone when a single byte addressable memory is adopted.